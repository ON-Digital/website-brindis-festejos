<?php
  if ( ! function_exists( 'dwf_svg_header_definitions' ) ) :
    function dwf_svg_header_definitions() {
      return '<svg class="sr-only">
        <defs>
        </defs>
      </svg>';
    }
  endif;
