<form role="search" method="get" class="search-form" id="search_form" action="http://localhost/wordpress-4.5.1-es_VE/">
  	<label id="search_field">
  			<span class="screen-reader-text sr-only">Search for:</span>
  			<input type="search" class="search-field form-control input-lg rounded-0" placeholder="Presiona enter para realizar una busqueda" value="" name="s" title="Search for:" />
  	</label>
</form>
