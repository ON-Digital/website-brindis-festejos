<?php
  echo '<div class="container">';

    echo '<div class="row mt-4 related-posts justify-content-center">';

      dynamic_sidebar( 'post-down' );

    echo '</div>';

  echo '</div>';
